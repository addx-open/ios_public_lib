# A4xBaseExtensionKit

[![CI Status](https://img.shields.io/travis/kieran'/A4xBaseExtensionKit.svg?style=flat)](https://travis-ci.org/kieran'/A4xBaseExtensionKit)
[![Version](https://img.shields.io/cocoapods/v/A4xBaseExtensionKit.svg?style=flat)](https://cocoapods.org/pods/A4xBaseExtensionKit)
[![License](https://img.shields.io/cocoapods/l/A4xBaseExtensionKit.svg?style=flat)](https://cocoapods.org/pods/A4xBaseExtensionKit)
[![Platform](https://img.shields.io/cocoapods/p/A4xBaseExtensionKit.svg?style=flat)](https://cocoapods.org/pods/A4xBaseExtensionKit)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

A4xBaseExtensionKit is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'A4xBaseExtensionKit'
```

## Author

wjin', wjin@a4x.ai

## License

A4xBaseExtensionKit is available under the MIT license. See the LICENSE file for more info.
