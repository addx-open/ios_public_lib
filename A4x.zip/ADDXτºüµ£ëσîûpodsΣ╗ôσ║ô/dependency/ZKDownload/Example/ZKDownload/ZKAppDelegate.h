//
//  ZKAppDelegate.h
//  ZKDownload
//
//  Created by kuiyu.zhi on 03/06/2019.
//  Copyright (c) 2019 kuiyu.zhi. All rights reserved.
//

@import UIKit;

@interface ZKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
