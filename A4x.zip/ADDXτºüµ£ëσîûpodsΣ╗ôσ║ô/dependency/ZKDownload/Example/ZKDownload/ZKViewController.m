//
//  ZKViewController.m
//  ZKDownload
//
//  Created by kuiyu.zhi on 03/06/2019.
//  Copyright (c) 2019 kuiyu.zhi. All rights reserved.
//

#import "ZKViewController.h"

@interface ZKViewController ()

@end

@implementation ZKViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
