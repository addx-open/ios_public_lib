//
//  main.m
//  ZKDownload
//
//  Created by kuiyu.zhi on 03/06/2019.
//  Copyright (c) 2019 kuiyu.zhi. All rights reserved.
//

@import UIKit;
#import "ZKAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZKAppDelegate class]));
    }
}
