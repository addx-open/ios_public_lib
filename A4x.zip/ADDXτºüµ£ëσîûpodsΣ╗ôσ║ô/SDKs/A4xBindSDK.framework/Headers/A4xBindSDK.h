//
//  A4xBindSDK.h
//  A4xBindSDK
//
//  Created by addx-wjin on 2021/7/12.
//

#import <Foundation/Foundation.h>

//! Project version number for A4xBindSDK.
FOUNDATION_EXPORT double A4xBindSDKVersionNumber;

//! Project version string for A4xBindSDK.
FOUNDATION_EXPORT const unsigned char A4xBindSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <A4xBindSDK/PublicHeader.h>


