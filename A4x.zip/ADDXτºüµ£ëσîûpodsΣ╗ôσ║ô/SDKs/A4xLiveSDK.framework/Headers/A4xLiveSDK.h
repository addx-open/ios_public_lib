//
//  A4xLiveSDK.h
//  A4xLiveSDK
//
//  Created by addx-wjin on 2021/7/12.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCrypto.h>

//! Project version number for A4xLiveSDK.
FOUNDATION_EXPORT double A4xLiveSDKVersionNumber;

//! Project version string for A4xLiveSDK.
FOUNDATION_EXPORT const unsigned char A4xLiveSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <A4xLiveSDK/PublicHeader.h>


