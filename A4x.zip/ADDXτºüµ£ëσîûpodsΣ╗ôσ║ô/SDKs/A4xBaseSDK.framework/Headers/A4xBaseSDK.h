//
//  A4xBaseSDK.h
//  A4xBaseSDK
//
//  Created by addx-wjin on 2021/7/12.
//

#import <Foundation/Foundation.h>

//! Project version number for A4xBaseSDK.
FOUNDATION_EXPORT double A4xBaseSDKVersionNumber;

//! Project version string for A4xBaseSDK.
FOUNDATION_EXPORT const unsigned char A4xBaseSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <A4xBaseSDK/PublicHeader.h>


